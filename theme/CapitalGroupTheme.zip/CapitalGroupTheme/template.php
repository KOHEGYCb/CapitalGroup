<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }

include('skeleton/header.php'); 

include('skeleton/content.php'); 

include('skeleton/footer.php'); 
?>
