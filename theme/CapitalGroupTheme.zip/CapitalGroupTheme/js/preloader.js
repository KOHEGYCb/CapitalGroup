    window.onload = function () {
        setTimeout(function () {
            document.getElementById('preloader').className = 'preloader_l';
        }, 500);
    }
