<div class="header"></div>

<div id="logo" class="logo">
<img src="<?php get_theme_url(); ?>/images/preloaderLogo.png" alt="">
<h4>CAPITAL GROUP</h4>
</div>
